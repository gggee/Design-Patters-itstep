package creational.AbstractFactory;

public interface IShape {
    void drawShape();
}
