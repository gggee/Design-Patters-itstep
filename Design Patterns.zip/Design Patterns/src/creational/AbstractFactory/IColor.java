package creational.AbstractFactory;

public interface IColor {
    void fillColor();
}
